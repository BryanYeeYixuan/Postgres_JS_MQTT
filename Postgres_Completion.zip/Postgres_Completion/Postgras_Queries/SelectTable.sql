-- TABLES WITH ALL THE SENSORS, INCUDING "NA" VALUES
SELECT u1.id,
	COALESCE(u1.value, 'NA') ultrasonic1,
	COALESCE(u2.value, 'NA') ultrasonic2,
	COALESCE(l.value, 'NA') lightsensor,
	COALESCE(t.value, 'NA') temperature,
	COALESCE(h.value, 'NA') humidity,
	COALESCE(w1.value, 'NA') waterlevel1,
	COALESCE(w2.value, 'NA') waterlevel2,
	COALESCE(w.value, 'NA') weight
FROM ultrasonic1_data u1
    LEFT JOIN ultrasonic2_data u2 ON u1.id = u2.id
    LEFT JOIN lightsensor_data l  ON u1.id = l.id
    LEFT JOIN temperature_data t  ON u1.id = t.id
    LEFT JOIN humidity_data    h  ON u1.id = h.id
    LEFT JOIN waterlevel1_data w1 ON u1.id = w1.id
    LEFT JOIN waterlevel2_data w2 ON u1.id = w2.id
    LEFT JOIN weight_data      w  ON u1.id = w.id
ORDER BY u1.id ASC;


-- TABLES WITH ALL THE SENSORS, WITHOUT "NA" VALUES
SELECT u1.id,
	u1.value ultrasonic1,
	u2.value ultrasonic2,
	l.value lightsensor,
	t.value temperature,
	h.value humidity,
	w1.value waterlevel1,
	w2.value waterlevel2,
	w.value weight
FROM ultrasonic1_data u1
    JOIN ultrasonic2_data u2 ON u1.id = u2.id
   	JOIN lightsensor_data l  ON u1.id = l.id
    JOIN temperature_data t  ON u1.id = t.id
    JOIN humidity_data    h  ON u1.id = h.id
    JOIN waterlevel1_data w1 ON u1.id = w1.id
    JOIN waterlevel2_data w2 ON u1.id = w2.id
    JOIN weight_data      w  ON u1.id = w.id
ORDER BY u1.id ASC;

