// Import the required libraries
const mqtt = require('mqtt');
const { Client } = require('pg');

// MQTT broker URL
const brokerUrl = 'mqtt://broker.hivemq.com'; // Replace with your MQTT broker URL

// PostgreSQL client configuration
const pgClient = new Client({
    user: 'postgres',          // Replace with your PostgreSQL username
    host: 'localhost',              // Replace with your PostgreSQL host
    database: 'mqtt',      // Replace with your PostgreSQL database name
    password: '1234567890',      // Replace with your PostgreSQL password
    port: 5432,                     // Replace with your PostgreSQL port if different
});

// List of topics to subscribe to
const topics = [
    'topic/ultrasonic1',
    'topic/ultrasonic2',
    'topic/humidity',
    'topic/temperature',
    'topic/waterlevel1',
    'topic/waterlevel2',
    'topic/lightsensor',
    'topic/weight'
];

// Create an MQTT client instance
const mqttClient = mqtt.connect(brokerUrl);

// Connect to PostgreSQL
pgClient.connect(err => {
    if (err) {
        console.error('Error connecting to PostgreSQL:', err);
        process.exit(1);
    }
    console.log('Connected to PostgreSQL');
});

// Event handler for when the MQTT client connects to the broker
mqttClient.on('connect', () => {
    console.log('Connected to MQTT broker');
    
    // Subscribe to all topics
    mqttClient.subscribe(topics, err => {
        if (err) {
            console.error('Subscription error:', err);
        } else {
            console.log(`Subscribed to topics: ${topics.join(', ')}`);
        }
    });
});

// Event handler for when a message is received
mqttClient.on('message', (topic, message) => {
    // Convert message to string
    const value = message.toString();
    console.log(`Message received on topic "${topic}": ${value}`);

    // Determine the table name based on the topic
    let tableName;
    switch (topic) {
        case 'topic/ultrasonic1':
            tableName = 'Ultrasonic1_Data';
            break;
        case 'topic/ultrasonic2':
            tableName = 'Ultrasonic2_Data';
            break;
        case 'topic/humidity':
            tableName = 'Humidity_Data';
            break;
        case 'topic/temperature':
            tableName = 'Temperature_Data';
            break;
        case 'topic/waterlevel1':
            tableName = 'Waterlevel1_Data';
            break;
        case 'topic/waterlevel2':
            tableName = 'Waterlevel2_Data';
            break;
        case 'topic/lightsensor':
            tableName = 'Lightsensor_Data';
            break;
        case 'topic/weight':
            tableName = 'Weight_Data';
            break;
        default:
            console.error(`Unknown topic: ${topic}`);
            return;
    }

    // Insert the received data into the appropriate PostgreSQL table
    const query = `INSERT INTO ${tableName} (value) VALUES ($1) RETURNING *`;
    const values = [value];

    pgClient.query(query, values, (err, res) => {
        if (err) {
            console.error(`Error inserting data into table ${tableName}:`, err);
        } else {
            console.log(`Data inserted into table ${tableName}:`, res.rows[0]);
        }
    });

    // Also insert into the overview table
    const overviewQuery = 'INSERT INTO Overview (topic, value) VALUES ($1, $2)';
    const overviewValues = [topic, value];

    pgClient.query(overviewQuery, overviewValues, (err, res) => {
        if (err) {
            console.error('Error inserting data into PostgreSQL Overview table:', err);
        } else {
            console.log('Data inserted into PostgreSQL Overview table');
        }
    });
});

// Event handler for errors
mqttClient.on('error', error => {
    console.error('MQTT error:', error);
});

// Handle process exit
process.on('exit', () => {
    mqttClient.end();
    pgClient.end();
});
