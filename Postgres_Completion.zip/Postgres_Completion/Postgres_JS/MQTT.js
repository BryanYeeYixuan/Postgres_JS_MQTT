// Import the required libraries
const mqtt = require('mqtt');
const { Client } = require('pg');

// MQTT broker URL
const brokerUrl = 'mqtt://broker.hivemq.com'; // Replace with your MQTT broker URL

// PostgreSQL client configuration
const pgClient = new Client({
    user: 'postgres',          // Replace with your PostgreSQL username
    host: 'localhost',              // Replace with your PostgreSQL host
    database: 'mqtt',      // Replace with your PostgreSQL database name
    password: '1234567890',      // Replace with your PostgreSQL password
    port: 5432,                     // Replace with your PostgreSQL port if different
});

// List of topics to subscribe to
const topics = [
    'topic/ultrasonic1',
    'topic/ultrasonic2',
    'topic/humidity',
    'topic/temperature',
    'topic/waterlevel1',
    'topic/waterlevel2',
    'topic/lightsensor',
    'topic/weight'
];

// Create an MQTT client instance
const mqttClient = mqtt.connect(brokerUrl);

// Connect to PostgreSQL
pgClient.connect(err => {
    if (err) {
        console.error('Error connecting to PostgreSQL:', err);
        process.exit(1);
    }
    console.log('Connected to PostgreSQL');
});

// Event handler for when the MQTT client connects to the broker
mqttClient.on('connect', () => {
    console.log('Connected to MQTT broker');
    
    // Subscribe to all topics
    mqttClient.subscribe(topics, err => {
        if (err) {
            console.error('Subscription error:', err);
        } else {
            console.log(`Subscribed to topics: ${topics.join(', ')}`);
        }
    });
});

// Event handler for when a message is received
mqttClient.on('message', (topic, message) => {
    // Convert message to string
    const msg = message.toString();
    console.log(`Message received on topic "${topic}": ${msg}`);

    // Insert the received data into PostgreSQL
    const query = 'INSERT INTO sensor_data (topic, message) VALUES ($1, $2)';
    const values = [topic, msg];

    pgClient.query(query, values, (err, res) => {
        if (err) {
            console.error('Error inserting data into PostgreSQL:', err);
        } else {
            console.log('Data inserted into PostgreSQL');
        }
    });
});

// Event handler for errors
mqttClient.on('error', error => {
    console.error('MQTT error:', error);
});

// Handle process exit
process.on('exit', () => {
    mqttClient.end();
    pgClient.end();
});
